import { FileText, EyeOff, AlertTriangle } from "lucide-react";
import ThinkingPanel from "./ThinkingPanel.jsx";
import ToolSummary from "./ToolActivity.jsx";

function formatTime(iso) {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch { return ""; }
}

function formatSize(bytes) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Adjuntos del mensaje ya enviado. Las imágenes se muestran como miniatura
 * servida desde /api/chat/attachments/<id>/raw (nunca base64 en el estado);
 * el resto como una etiqueta con el nombre y el tamaño.
 */
function MessageAttachments({ attachments }) {
  if (!attachments || attachments.length === 0) return null;

  const images = attachments.filter((a) => a.kind === "image" && a.url && a.status === "ready");
  const rest = attachments.filter((a) => !images.includes(a));

  return (
    <div className="flex flex-col gap-1.5 mb-1.5 w-full">
      {images.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {images.map((a) => (
            <a key={a.id} href={a.url} target="_blank" rel="noreferrer" title={a.filename}>
              <img
                src={a.url}
                alt={a.filename}
                className="h-24 w-24 object-cover rounded-md border border-white/10"
              />
            </a>
          ))}
        </div>
      )}

      {rest.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {rest.map((a) => {
            const skipped = a.status === "vision_unsupported";
            const failed = a.status === "error";
            const Icon = skipped ? EyeOff : failed ? AlertTriangle : FileText;
            return (
              <span
                key={a.id}
                title={a.error || a.note || a.filename}
                className={
                  "inline-flex items-center gap-1.5 px-2 py-1 rounded-md border text-xs " +
                  (failed
                    ? "border-red-500/40 bg-red-500/10 text-red-300"
                    : skipped
                      ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                      : "border-white/10 bg-black/30 text-glyvex-text")
                }
              >
                <Icon size={12} className="shrink-0" />
                <span className="truncate max-w-[180px]">{a.filename}</span>
                {a.size > 0 && <span className="opacity-60 tabular-nums">{formatSize(a.size)}</span>}
              </span>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function MessageBubble({ message, streaming = false }) {
  const isUser = message.role === "user";
  const hasAttachments = Array.isArray(message.attachments) && message.attachments.length > 0;

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} group`}>
      <div className={`max-w-[75%] ${isUser ? "items-end" : "items-start"} flex flex-col`}>
        {!isUser && <ToolSummary activity={message.tool_activity} />}
        {!isUser && <ThinkingPanel thinking={message.thinking} />}
        {isUser && <MessageAttachments attachments={message.attachments} />}

        {(message.content || !hasAttachments) && (
          <div
            className={
              "rounded-lg px-4 py-2.5 text-sm whitespace-pre-wrap break-words " +
              (isUser ? "bg-glyvex-accent text-white" : "bg-glyvex-card text-glyvex-text")
            }
          >
            {message.content}
            {streaming && <span className="inline-block w-1.5 h-4 bg-current align-text-bottom ml-0.5 animate-pulse" />}
          </div>
        )}

        <div className="flex items-center gap-2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <span className="text-xs text-glyvex-muted">{formatTime(message.timestamp)}</span>
          {!isUser && message.metrics?.tps ? (
            <span className="text-xs text-glyvex-muted font-mono">
              {message.metrics.tps.toFixed(1)} t/s
              {message.metrics.ttft_ms ? ` · ${Math.round(message.metrics.ttft_ms)}ms TTFT` : ""}
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
