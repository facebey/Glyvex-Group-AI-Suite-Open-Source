"""
config.py — Manejo de configuración persistente para Glyvex-AI-Suite.

Usa un modelo Pydantic v2 como esquema/validación y expone acceso por
dot-notation (config.get("app.port"), config.set("app.port", 7860)) sobre
un dict interno, con persistencia async en JSON vía aiofiles.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import aiofiles
from pydantic import BaseModel, Field

# Ruta del archivo de configuración: <repo>/data/config.json
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "data" / "config.json"


class BackendConfig(BaseModel):
    binary_path: str = ""
    default_port: int = 8080
    enabled: bool = True


class UnslothConfig(BaseModel):
    python_env: str = ""
    enabled: bool = False


class BackendsConfig(BaseModel):
    llama_server: BackendConfig = Field(
        default_factory=lambda: BackendConfig(default_port=8080, enabled=True)
    )
    ollama: BackendConfig = Field(
        default_factory=lambda: BackendConfig(
            binary_path="/usr/bin/ollama", default_port=11434, enabled=False
        )
    )
    lm_studio: BackendConfig = Field(
        default_factory=lambda: BackendConfig(default_port=1234, enabled=False)
    )
    unsloth: UnslothConfig = Field(default_factory=UnslothConfig)


class HardwareConfig(BaseModel):
    gpu_model: str = ""
    vram_gb: int = 0
    ram_gb: int = 0
    cpu_model: str = ""
    cpu_cores: int = 0


class AppConfig(BaseModel):
    port: int = 7860
    theme: str = "dark"
    language: str = "es"


class AttachmentsConfig(BaseModel):
    """Límites del chat para adjuntos (módulo M3, Bloque 1)."""

    max_file_mb: int = 16
    max_files_per_message: int = 10
    # Tope de texto extraído por archivo. Se guarda dentro del mensaje, así
    # que también acota cuánto crece la fila de chat_conversations.
    max_text_chars: int = 50_000
    # Costo estimado de una imagen para el aviso de contexto. Varía mucho
    # entre modelos de visión, por eso es configurable y no una constante.
    image_tokens_estimate: int = 1024


class ToolsConfig(BaseModel):
    """Búsqueda y navegación web del chat (módulo M3, Bloque 2)."""

    # Proveedor de búsqueda: "ddgs" | "searxng" | "brave" | "tavily".
    # El default no necesita servidor ni key, así que funciona dentro del
    # bundle de Tauri sin que el usuario instale nada aparte.
    search_provider: str = "ddgs"
    # Región de DuckDuckGo: "wt-wt" es global, "ar-es" Argentina, etc.
    region: str = "wt-wt"
    # Solo para search_provider = "searxng". La imagen Docker escucha en 8080
    # adentro del contenedor — el mismo puerto que llama-server — así que el
    # mapeo habitual es -p 8888:8080.
    searxng_url: str = "http://127.0.0.1:8888"
    # Se leen antes las variables de entorno BRAVE_API_KEY y TAVILY_API_KEY:
    # dejar un secreto acá lo escribe en config.json.
    brave_api_key: str = ""
    tavily_api_key: str = ""

    max_results: int = 5
    fetch_max_chars: int = 8000
    # Tope de idas y vueltas modelo↔tool dentro de un mismo turno.
    max_rounds: int = 5
    timeout_s: float = 20.0
    # fetch_url recibe la URL del modelo, no del usuario: un resultado de
    # búsqueda podría intentar apuntarlo a la red interna. Habilitalo solo si
    # querés que pueda leer páginas de tu propia LAN.
    allow_private_hosts: bool = False
    user_agent: str = "Glyvex-AI-Suite/0.1"


class ConfigSchema(BaseModel):
    """Esquema completo de config.json, usado solo para validar/generar defaults."""

    app: AppConfig = Field(default_factory=AppConfig)
    hardware: HardwareConfig = Field(default_factory=HardwareConfig)
    backends: BackendsConfig = Field(default_factory=BackendsConfig)
    attachments: AttachmentsConfig = Field(default_factory=AttachmentsConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    model_dirs: list[str] = Field(default_factory=list)
    last_used_model: str | None = None
    auto_start_last: bool = False


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Merge recursivo: patch pisa a base, sin borrar claves no incluidas en patch."""
    result = dict(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


class Config:
    """
    Wrapper de configuración con acceso por dot-notation y persistencia async.

    Uso:
        config = Config()
        await config.load()
        config.get("app.port")          # -> 7860
        config.set("app.port", 8000)
        await config.save()
    """

    def __init__(self, path: Path = CONFIG_PATH) -> None:
        self.path = path
        self._data: dict[str, Any] = json.loads(ConfigSchema().model_dump_json())

    @property
    def data(self) -> dict[str, Any]:
        return self._data

    def defaults(self) -> dict[str, Any]:
        return json.loads(ConfigSchema().model_dump_json())

    def get(self, key: str, default: Any = None) -> Any:
        node: Any = self._data
        for part in key.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return default
        return node

    def set(self, key: str, value: Any) -> None:
        parts = key.split(".")
        node = self._data
        for part in parts[:-1]:
            if part not in node or not isinstance(node[part], dict):
                node[part] = {}
            node = node[part]
        node[parts[-1]] = value

    def update(self, patch: dict[str, Any]) -> None:
        """Merge parcial (recursivo) sobre la config actual."""
        self._data = _deep_merge(self._data, patch)

    async def load(self) -> dict[str, Any]:
        if not self.path.exists():
            self.path.parent.mkdir(parents=True, exist_ok=True)
            await self.save()
            return self._data

        async with aiofiles.open(self.path, "r", encoding="utf-8") as f:
            raw = await f.read()

        try:
            loaded = json.loads(raw) if raw.strip() else {}
        except json.JSONDecodeError:
            loaded = {}

        # Merge sobre los defaults para tolerar config.json parcial o de una
        # versión anterior del esquema.
        self._data = _deep_merge(self.defaults(), loaded)
        return self._data

    async def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(self.path, "w", encoding="utf-8") as f:
            await f.write(json.dumps(self._data, indent=2, ensure_ascii=False))

    async def reset(self) -> dict[str, Any]:
        self._data = self.defaults()
        await self.save()
        return self._data


# Instancia única compartida por toda la app (importada por main.py y routers)
config = Config()
